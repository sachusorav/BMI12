# Brain Controlled Command

 classification of EEG signals for attention and relaxed states.
 
